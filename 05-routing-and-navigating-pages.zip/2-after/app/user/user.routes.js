"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var profile_component_1 = require("./profile.component");
exports.userRoutes = [
    { path: 'profile', component: profile_component_1.ProfileComponent }
];
//# sourceMappingURL=user.routes.js.map